<template>
       <div>
        <h1>轻课</h1>
    </div>
</template>

<script>
    export default {
        name: "LightCourse"
    }
</script>

<style scoped>

</style>