<template>
           <div>
        <h1>实战课</h1>
    </div>
</template>

<script>
    export default {
        name: "ActualCourse"
    }
</script>

<style scoped>

</style>