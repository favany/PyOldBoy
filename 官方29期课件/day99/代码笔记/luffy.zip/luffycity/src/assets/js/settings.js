export default {
    base_url: 'http://47.103.156.13:8000'
}