

from celery_task.task1 import add
from celery_task.task2 import mutile


# ret=add(6,7)
# print(ret)

# # 提交任务
# ret=add.delay(6,7)
# print(ret)  # 2d4ad592-9548-4c7c-8df4-7f8583e8a1b1
#
# ret=mutile.delay(9,9)
# print(ret)


# 执行延迟任务

# 添加延迟任务
from datetime import datetime, timedelta

# print(datetime.utcnow())
# print(type(timedelta(seconds=10)))
# eta=datetime.utcnow() + timedelta(days=10)
# print(eta)
# print(type(eta))
#
#
# # 需要utc时间
# eta=datetime.utcnow() + timedelta(seconds=10)
# ret=add.apply_async(args=(240, 50), eta=eta)
# print(ret)

