


s1='throttle_%(scope)s_%(ident)s'


s2='throttle_%s_%s'
print(s1%{'scope':'sms','ident':189673333})
print(s2%('sms',189673333))