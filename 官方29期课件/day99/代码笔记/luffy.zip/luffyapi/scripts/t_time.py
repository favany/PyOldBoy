


import time

for i in range(10):
    ctime=str(time.time())
    print(ctime)