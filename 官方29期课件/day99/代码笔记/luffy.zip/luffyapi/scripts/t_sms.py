

# 短信应用 SDK AppID
appid = 1400397846  # SDK AppID 以1400开头
# 短信应用 SDK AppKey
appkey = "fd972f6d5a15add46de47b50b8dbe930"
# 需要发送短信的手机号码
ll=['17681790058','18701244561']
# 短信模板ID，需要在短信控制台中申请
template_id = 661935  # NOTE: 这里的模板 ID`7839`只是示例，真实的模板 ID 需要在短信控制台中申请
# 签名
sms_sign = "小猿取经"  # NOTE: 签名参数使用的是`签名内容`，而不是`签名ID`。这里的签名"腾讯云"只是示例，真实的签名需要在短信控制台中申请



from qcloudsms_py import SmsSingleSender
from qcloudsms_py.httpclient import HTTPError
ssender = SmsSingleSender(appid, appkey)
params = ["1234",'3']  # 当模板没有参数时，`params = []`
try:
  result = ssender.send_with_param(86, ll[0],template_id, params, sign=sms_sign, extend="", ext="")
  result = ssender.send_with_param(86, ll[1],template_id, params, sign=sms_sign, extend="", ext="")
  if result.get('result')==0:
      pass

except HTTPError as e:
  print(e)
except Exception as e:
  print(e)
