

# 首页轮播图个数
BANNER_COUNTER=3


# 手机验证码缓存的key值
PHONE_CACHE_KEY='sms_cache_%s'